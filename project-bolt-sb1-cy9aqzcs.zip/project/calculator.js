class Calculator {
    constructor() {
        this.result = 0;
    }

    add(a, b) {
        this.result = a + b;
        return this.result;
    }

    subtract(a, b) {
        this.result = a - b;
        return this.result;
    }

    multiply(a, b) {
        this.result = a * b;
        return this.result;
    }

    divide(a, b) {
        if (b === 0) {
            throw new Error("Cannot divide by zero!");
        }
        this.result = a / b;
        return this.result;
    }

    getResult() {
        return this.result;
    }
}

// Demo the calculator
const calc = new Calculator();
console.log("Welcome to Simple Calculator!");
console.log("Adding 5 + 3 =", calc.add(5, 3));
console.log("Subtracting 10 - 4 =", calc.subtract(10, 4));
console.log("Multiplying 6 * 2 =", calc.multiply(6, 2));
console.log("Dividing 15 / 3 =", calc.divide(15, 3));

export default Calculator;