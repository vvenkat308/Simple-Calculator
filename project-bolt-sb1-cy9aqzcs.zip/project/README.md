# Simple Java Calculator

This is a basic Java calculator project that demonstrates fundamental Java programming concepts. It includes:

- Basic arithmetic operations (add, subtract, multiply, divide)
- Object-oriented programming with a Calculator class
- Exception handling for division by zero
- Unit tests using JUnit

## Features

- Addition of two numbers
- Subtraction of two numbers
- Multiplication of two numbers
- Division of two numbers (with division by zero check)
- Result storage and retrieval
- Comprehensive unit tests

## How to Run

1. Compile the Java files
2. Run the Calculator class to see the demo
3. Run the CalculatorTest class to execute the unit tests

## Example Usage

```java
Calculator calc = new Calculator();
int sum = calc.add(5, 3);      // Returns 8
int diff = calc.subtract(10, 4); // Returns 6
int product = calc.multiply(6, 2); // Returns 12
int quotient = calc.divide(15, 3); // Returns 5
```

## Project Structure

- `Calculator.java`: Main calculator implementation
- `CalculatorTest.java`: Unit tests for the calculator