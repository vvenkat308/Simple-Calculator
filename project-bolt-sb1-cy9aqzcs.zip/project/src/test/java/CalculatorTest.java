import org.junit.Test;
import static org.junit.Assert.*;

public class CalculatorTest {
    private Calculator calculator = new Calculator();

    @Test
    public void testAdd() {
        assertEquals(8, calculator.add(5, 3));
    }

    @Test
    public void testSubtract() {
        assertEquals(6, calculator.subtract(10, 4));
    }

    @Test
    public void testMultiply() {
        assertEquals(12, calculator.multiply(6, 2));
    }

    @Test
    public void testDivide() {
        assertEquals(5, calculator.divide(15, 3));
    }

    @Test(expected = ArithmeticException.class)
    public void testDivideByZero() {
        calculator.divide(10, 0);
    }
}