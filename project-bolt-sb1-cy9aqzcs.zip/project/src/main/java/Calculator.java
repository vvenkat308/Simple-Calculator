public class Calculator {
    private int result;

    public Calculator() {
        this.result = 0;
    }

    public int add(int a, int b) {
        result = a + b;
        return result;
    }

    public int subtract(int a, int b) {
        result = a - b;
        return result;
    }

    public int multiply(int a, int b) {
        result = a * b;
        return result;
    }

    public int divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero!");
        }
        result = a / b;
        return result;
    }

    public int getResult() {
        return result;
    }

    public static void main(String[] args) {
        Calculator calc = new Calculator();
        
        System.out.println("Welcome to Simple Calculator!");
        System.out.println("Adding 5 + 3 = " + calc.add(5, 3));
        System.out.println("Subtracting 10 - 4 = " + calc.subtract(10, 4));
        System.out.println("Multiplying 6 * 2 = " + calc.multiply(6, 2));
        System.out.println("Dividing 15 / 3 = " + calc.divide(15, 3));
    }
}