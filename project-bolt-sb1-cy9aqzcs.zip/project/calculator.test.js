import Calculator from './calculator.js';

describe('Calculator', () => {
    let calculator;

    beforeEach(() => {
        calculator = new Calculator();
    });

    test('adds two numbers correctly', () => {
        expect(calculator.add(5, 3)).toBe(8);
    });

    test('subtracts two numbers correctly', () => {
        expect(calculator.subtract(10, 4)).toBe(6);
    });

    test('multiplies two numbers correctly', () => {
        expect(calculator.multiply(6, 2)).toBe(12);
    });

    test('divides two numbers correctly', () => {
        expect(calculator.divide(15, 3)).toBe(5);
    });

    test('throws error when dividing by zero', () => {
        expect(() => calculator.divide(10, 0)).toThrow('Cannot divide by zero!');
    });
});